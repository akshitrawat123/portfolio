# How to Contribute

Thank you for considering contributing to Ezfolio.

## Getting Started

1.  Fork the Repository and Create a Branch
2.  Commit Changes
3.  Submit a Pull Request

## Credit

If you are adding a 3rd party template for frontend, be sure to add any required credit or copyright notice where it is applicable.

## Contact
If you have any question, please feel free to contact us via email : <strong><a href="mailto:arifulalamszn@gmail.com">arifulalamszn@gmail.com</a></strong>.
