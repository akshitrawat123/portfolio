<?php

return [
    'demo_mode' => false,
];
