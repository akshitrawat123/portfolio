<div id="szn-preloader">
    <style>
        #szn-preloader {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 9999;
            background-image: url("{{asset('/assets/common/img/preloading.gif')}}");
            background-repeat: no-repeat;
            background-color: #FFF;
            background-position: center;
        }
    </style>
</div>